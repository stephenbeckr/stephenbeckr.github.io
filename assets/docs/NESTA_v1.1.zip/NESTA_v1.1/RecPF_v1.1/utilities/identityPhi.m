function Y = identityPhi(X)
    Y = X;