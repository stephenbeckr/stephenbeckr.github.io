function y = A_Subset(x,Omega);

y = x(Omega);
